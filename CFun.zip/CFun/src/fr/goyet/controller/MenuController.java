package fr.goyet.controller;

import java.io.IOException;

import fr.goyet.CFunApp;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;

public class MenuController {

	@FXML
	private MenuItem gestionnaire;
	
	@FXML
	private MenuItem accueil;
	
	@FXML
	private MenuItem quitter;
	
	@FXML
	private MenuItem help;

	private CFunApp cfunApp;
	
	
	@FXML
	void onClickGestionnaire(ActionEvent event) throws IOException {
		CFunApp.afficheVue("View/View_Identification.fxml");
	}
	
	@FXML
	void onClickAccueil(ActionEvent event) throws IOException{
		CFunApp.afficheVue("View/View_Accueil.fxml");
	}
	
	@FXML
	void onClickHelp(ActionEvent event) {
	
	}
	
	@FXML
	void onClickQuitter(ActionEvent event) {
		System.exit(0);
	}
	
	public void setCFunApp(CFunApp cfunApp) {
		this.cfunApp = cfunApp;
	}
}
