package fr.goyet.controller;

import java.io.IOException;
import java.util.ArrayList;

import fr.goyet.CFunApp;
import fr.goyet.model.Billet;
import fr.goyet.tools.Outils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class EntreeController {
	
	@FXML
    private Label numEntree;
	
	@FXML
	private Label idSalle;

    @FXML
    private Label dateEntree;

    @FXML
	private Label heureEntree;

    @FXML
    private Button imprimer;
    
    public ArrayList<Billet> listeBilletEntree = SalleController.getListeBilletEntree();
    
    @FXML
    public void initialize() {
    	Billet billetEnCours = Outils.recupBilletEnCours(listeBilletEntree);
		
		initialisationBillet(billetEnCours);
    }
    
    public void setMainApp(CFunApp mainApp) {
	}

    @FXML
    void onClickImprimer(ActionEvent event) throws IOException {
    	CFunApp.afficheVue("View/View_Accueil.fxml");
    }
    
    public void onClickQuitter() {
    	System.exit(0);
    }
    
    public void initialisationBillet(Billet billet) {
    	numEntree.setText(Integer.toString(billet.getNumBilletEntree()));
		System.out.println(numEntree);
		idSalle.setText(billet.getNomSalle());
		dateEntree.setText(billet.getDate());
		heureEntree.setText(billet.getHeure());
    }

}
