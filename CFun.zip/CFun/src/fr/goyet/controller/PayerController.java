package fr.goyet.controller;

import java.io.IOException;
import java.util.ArrayList;

import fr.goyet.CFunApp;
import fr.goyet.model.Billet;
import fr.goyet.tools.Outils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class PayerController {
	
	@FXML
    private Label numSortie;

    @FXML
    private Label dateSortie;

    @FXML
    private Label heureSortie;

    @FXML
    private Label montant;

    @FXML
    private Button payer;
    
    public ArrayList<Billet> listeBilletSortie = SortieController.getListeBilletSortie();

    @FXML
    public void initialize() {
    	Billet billetEnCours = Outils.recupBilletEnCours(listeBilletSortie);
		
		initialisationBillet(billetEnCours);
    }
    
    public void setMainApp(CFunApp mainApp) {
   	}
    
    @FXML
    void onClickPayer(ActionEvent event) throws IOException {
    	CFunApp.afficheVue("View/View_Accueil.fxml");
    }
    
    public void onClickQuitter() {
    	System.exit(0);
    }
    
    public void initialisationBillet(Billet billetEnCours) {
    	numSortie.setText(Integer.toString(billetEnCours.getNumBilletSortie()));
		System.out.println(numSortie);
		dateSortie.setText(billetEnCours.getDate());
		heureSortie.setText(billetEnCours.getHeure());
		montant.setText((billetEnCours.getMontant()).toString() + " €");
    }
}
