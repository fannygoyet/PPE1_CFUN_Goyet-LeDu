package fr.goyet.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import fr.goyet.CFunApp;
import fr.goyet.model.Billet;
import fr.goyet.model.Fitness;
import fr.goyet.model.Musculation;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class SalleController {

	@FXML
    private Button musculation;

    @FXML
    private Button fitness;

    @FXML
    private Button muscuRouge;
    
    @FXML
    private Button muscuOrange;
    
    @FXML
    private Button muscuVert;
    
    @FXML
    private Button fitnessRouge;
    
    @FXML
    private Button fitnessOrange;
    
    @FXML
    private Button fitnessVert;
    
    public static Musculation salleMuscu = new Musculation();
	public static Fitness salleFitness = new Fitness();
	public static ArrayList<Billet> listeBilletEntree = new ArrayList<Billet>();
	
	@FXML
	void initialize() {
		if(salleFitness.getTauxOccupation() < 70) {
			fitnessRouge.setVisible(false);
			fitnessOrange.setVisible(false);
			fitnessVert.setVisible(true);
		}
		if(salleFitness.getTauxOccupation() > 70 && salleFitness.getTauxOccupation() < 100) {
			fitnessRouge.setVisible(false);
			fitnessOrange.setVisible(true);
			fitnessVert.setVisible(false);
		}
		if(salleFitness.getTauxOccupation() == 100) {
			fitnessRouge.setVisible(true);
			fitnessOrange.setVisible(false);
			fitnessVert.setVisible(false);
		}
		if(salleMuscu.getTauxOccupation() < 70) {
			muscuRouge.setVisible(false);
			muscuOrange.setVisible(false);
			muscuVert.setVisible(true);
		}
		if(salleMuscu.getTauxOccupation() > 70 && salleMuscu.getTauxOccupation() < 100) {
			muscuRouge.setVisible(false);
			muscuOrange.setVisible(true);
			muscuVert.setVisible(false);
		}
		if(salleMuscu.getTauxOccupation() == 100) {
			muscuRouge.setVisible(true);
			muscuOrange.setVisible(false);
			muscuVert.setVisible(false);
		}
	}
    
    @FXML
    void onClickFitness(ActionEvent event) throws IOException {
    	if(salleFitness.getNbPlaceOccupee() < salleFitness.getNbPlace()) {
			salleFitness.addFitnessPeople();
			DateFormat djour = new SimpleDateFormat("dd/MM/yy");
			DateFormat dheure = new SimpleDateFormat("HH:mm");
			Date date = new Date();
			Billet billet = new Billet(salleFitness.getNomSalle(),djour.format(date.getTime()),dheure.format(date.getTime()));
			listeBilletEntree.add(billet);
			CFunApp.afficheVue("View/View_Entree.fxml");
		}
    }

    @FXML
    void onClickMusculation(ActionEvent event) throws IOException {
    	if(salleMuscu.getNbPlaceOccupee() < salleMuscu.getNbPlace()) {
			salleMuscu.addMuscuPeople();
			DateFormat djour = new SimpleDateFormat("dd/MM/yy");
			DateFormat dheure = new SimpleDateFormat("HH:mm");
			Date date = new Date();
			Billet billet = new Billet(salleMuscu.getNomSalle(),djour.format(date.getTime()),dheure.format(date.getTime()));
			listeBilletEntree.add(billet);
			CFunApp.afficheVue("View/View_Entree.fxml");
		}
    }
    
    public void onClickQuitter() {
    	System.exit(0);
    }

	public static ArrayList<Billet> getListeBilletEntree() {
		return listeBilletEntree;
	}

	public void setListeBilletEntree(ArrayList<Billet> listeBilletEntree) {
		SalleController.listeBilletEntree = listeBilletEntree;
	}
    
}
