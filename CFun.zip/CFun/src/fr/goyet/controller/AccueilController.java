package fr.goyet.controller;

import java.io.IOException;

import fr.goyet.CFunApp;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class AccueilController {
	
	@FXML
    private Button entrer;

    @FXML
    private Button sortir;

    @FXML
    public void onClickEntrer(ActionEvent event) throws IOException {
    	CFunApp.afficheVue("View/View_Salle.fxml");
    }

    @FXML
    public void onClickSortir(ActionEvent event) throws IOException {
    	CFunApp.afficheVue("View/View_Sortie.fxml");
    }
    
    public void onClickQuitter() {
    	System.exit(0);
    }
}
