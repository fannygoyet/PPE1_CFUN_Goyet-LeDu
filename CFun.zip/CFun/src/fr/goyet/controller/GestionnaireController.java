package fr.goyet.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class GestionnaireController {

	 @FXML
    private Label nbPlaceM;

    @FXML
    private Label nbPlaceOccupeeM;

    @FXML
    private Label nbPlaceLibreM;

    @FXML
    private Label tauxOccupationM;

    @FXML
    private Label nbPlaceF;

    @FXML
    private Label nbPlaceOccupeeF;

    @FXML
    private Label nbPlaceLibreF;

    @FXML
    private Label tauxOccupationF;
	
    @FXML
    void initialize() {
    	nbPlaceM.setText((SalleController.salleMuscu.getNbPlace()).toString());
    	nbPlaceOccupeeM.setText((SalleController.salleMuscu.getNbPlaceOccupee()).toString());
    	nbPlaceLibreM.setText((SalleController.salleMuscu.getNbPlaceLibre()).toString());
    	tauxOccupationM.setText((SalleController.salleMuscu.getTauxOccupation()).toString() + " %");
    	
    	nbPlaceF.setText((SalleController.salleFitness.getNbPlace()).toString());
    	nbPlaceOccupeeF.setText((SalleController.salleFitness.getNbPlaceOccupee()).toString());
    	nbPlaceLibreF.setText((SalleController.salleFitness.getNbPlaceLibre()).toString());
    	tauxOccupationF.setText((SalleController.salleFitness.getTauxOccupation()).toString() + " %");    	
    }
}
