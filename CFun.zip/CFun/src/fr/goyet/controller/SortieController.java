package fr.goyet.controller;

import java.io.IOException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import fr.goyet.CFunApp;
import fr.goyet.model.Billet;
import fr.goyet.tools.Outils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SortieController {

	@FXML
    private Button payer;

    @FXML
    private TextField numBillet;

    @FXML
    private Label messageStatut;

    public ArrayList<Billet> listeBilletEntree = SalleController.getListeBilletEntree();
    public static ArrayList<Billet> listeBilletSortie = new ArrayList<Billet>();
    
    @FXML
    void onClickSortir(ActionEvent event) throws IOException, ParseException {
    	Integer num = Integer.parseInt(numBillet.getText());
    	for(Billet unBillet : SalleController.listeBilletEntree) {
    		if(unBillet.getNumBilletEntree() == num) {
    			
    			DateFormat djour = new SimpleDateFormat("dd/MM/yy");
    			DateFormat dheure = new SimpleDateFormat("HH:mm");
    			Date date = new Date();
    			String fin = dheure.format(date.getTime());
    			String deb = unBillet.getHeure();
    			
    			int temps = Outils.calculTemps(deb,fin);
    			Double montant = Outils.calculMontant(temps);
    			Billet billetSortie = new Billet(djour.format(date.getTime()),fin, montant);
    			listeBilletSortie.add(billetSortie);
    			
    			sortirPeople(unBillet);
    			SalleController.listeBilletEntree.remove(unBillet);
    			
    			
    			CFunApp.afficheVue("View/View_Payer.fxml");
    		} else {
    			messageStatut.setText("Je n'ai pas trouvé le billet");
    		}
    	}
    }
    
    public void sortirPeople(Billet unBillet) {
    	String typeSalle = unBillet.getNomSalle();
    	if(typeSalle == "Fitness") {
    		SalleController.salleFitness.removePeople();
    	} else if(typeSalle == "Musculation"){
    		SalleController.salleMuscu.removePeople();
    	}
    }

	public static ArrayList<Billet> getListeBilletSortie() {
		return listeBilletSortie;
	}

	public void setListeBilletSortie(ArrayList<Billet> listeBilletSortie) {
		SortieController.listeBilletSortie = listeBilletSortie;
	}
}
