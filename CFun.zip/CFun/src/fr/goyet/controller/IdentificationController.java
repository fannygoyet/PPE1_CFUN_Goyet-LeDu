package fr.goyet.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import fr.goyet.CFunApp;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class IdentificationController implements Initializable {

	@FXML
    private TextField user;

    @FXML
    private PasswordField password;

    @FXML
    private Button login;
    
    @Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

    @FXML
    void makeLogin(ActionEvent event) throws IOException {
    	String username = user.getText();
    	String pass = password.getText();
    	if(username.equals("admin") && pass.contentEquals("admin")) {
    		CFunApp.afficheVue("View/View_Gestionnaire.fxml");
    	} else {
    		System.out.println("Mauvais mot de passe");
    	}
	}
	
	public void onClickQuitter() {
    	System.exit(0);
    }
	

}
