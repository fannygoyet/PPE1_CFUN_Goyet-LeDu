package fr.goyet.tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import fr.goyet.model.Billet;

public class Outils {
	
	public static Billet recupBilletEnCours(ArrayList<Billet> listeBillet) {
		return listeBillet.get(listeBillet.size() - 1);
    }
	
	public static int calculTemps(String deb, String fin) throws ParseException {
		Date HD = new SimpleDateFormat("hh:mm").parse(deb);
		Date HF = new SimpleDateFormat("hh:mm").parse(fin);
		
		GregorianCalendar cal = new GregorianCalendar();
		
		cal.setTime(HF);
		int finH = cal.get(Calendar.HOUR);
		cal.setTime(HD);
		int debH = cal.get(Calendar.HOUR);
		return finH - debH;
	}
	
	public static Double calculMontant(Integer temps) {
    	double montant = 0;
    	if(temps <= 60) {
			if(temps >= 0 && temps <= 15) {
				montant = 0;
			} 
			if(temps > 15 && temps <= 30) {
				montant = 0.50;
			}
			if (temps >30 && temps <= 60) {
				montant = 1;
			}
    	} else if(temps > 60){
    		montant = 1;
    		for(int i = 60; i <= temps; i = i + 15) {
    			montant += 0.5;
    		}
    	}
    	return montant;
    }
}