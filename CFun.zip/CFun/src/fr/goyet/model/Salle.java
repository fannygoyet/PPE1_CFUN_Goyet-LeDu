package fr.goyet.model;

public interface Salle {
	String getNomSalle();
    Integer getNbPlace();
    Integer getNbPlaceOccupee();
    Integer getNbPlaceLibre();
    Double getTauxOccupation();
    void setNbPlace(Integer nombre);
}
