package fr.goyet.model;


public class Fitness implements Salle {
	
	private String nomSalle = "Fitness";
	private static int nbPlace = 5;
	private static int nbPlaceOccupee = 0;
	
	public Fitness() {
	}

	@Override
	public String getNomSalle() {
		return nomSalle;
	}

	@Override
	public Integer getNbPlace() {
		return nbPlace;
	}

	@Override
	public Integer getNbPlaceOccupee() {
		return nbPlaceOccupee;
	}

	@Override
	public Double getTauxOccupation() {
		double nbPlaceOccupees = nbPlaceOccupee;
        double nbPlaces = nbPlace;
        Double tauxOccupation = (nbPlaceOccupees / nbPlaces) * 100.0;
        tauxOccupation = (double) Math.round(tauxOccupation*100.0)/100.0;
        return tauxOccupation;
	}

	public void addFitnessPeople() {
		nbPlaceOccupee++;
	}
	
	public void removePeople() {
		nbPlaceOccupee = nbPlaceOccupee -1;
	}


	@Override
	public Integer getNbPlaceLibre() {
		return nbPlace - nbPlaceOccupee;
	}

	@Override
	public void setNbPlace(Integer nombre) {
		// TODO Auto-generated method stub
		
	}
}
