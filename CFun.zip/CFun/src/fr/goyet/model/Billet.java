package fr.goyet.model;

public class Billet {
	
	private static Integer compteurBilletEntree = 1;
	private static Integer compteurBilletSortie = 1;
	
	private Integer numBilletEntree;
	private Integer numBilletSortie;
	private String nomSalle;
	private String date;
	private String heure;
	private Double montant;
		
	public Billet(String date, String heure, Double montant) {
		this.setNumBilletSortie(compteurBilletSortie);
		this.date = date;
		this.heure = heure;
		this.montant = montant;

		Billet.compteurBilletSortie = Billet.compteurBilletSortie+1;
	}	

	public Billet(String nomSalle, String date, String heure) {
		this.setNumBilletEntree(compteurBilletEntree);
		this.nomSalle = nomSalle;
		this.date = date;
		this.heure = heure;
		
		Billet.compteurBilletEntree = compteurBilletEntree+1;
	}
	
	public String getNomSalle() {
		return nomSalle;
	}
	
	public void setNomSalle(String nomSalle) {
		this.nomSalle = nomSalle;
	}
	
	public String getDate() {
		return date;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getHeure() {
		return heure;
	}
	
	public void setHeure(String heure) {
		this.heure = heure;
	}
	
	public Double getMontant() {
		return montant;
	}
	
	public void setMontant(Double montant) {
		this.montant = montant;
	}

	public Integer getNumBilletEntree() {
		return numBilletEntree;
	}

	public void setNumBilletEntree(Integer numBilletEntree) {
		this.numBilletEntree = numBilletEntree;
	}

	public Integer getNumBilletSortie() {
		return numBilletSortie;
	}

	public void setNumBilletSortie(Integer numBilletSortie) {
		this.numBilletSortie = numBilletSortie;
	}
}
