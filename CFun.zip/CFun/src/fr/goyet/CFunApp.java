package fr.goyet;

import java.io.IOException;

import fr.goyet.controller.MenuController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class CFunApp extends Application{
	
//	private BorderPane menu;
	private static Scene scene;
	private static BorderPane menu;
	private final String TITRE = "Complexe CFun";
	private Stage primaryStage;

	
	
	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle(TITRE);
		this.primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("resource/CFUN_logo.png")));
		try {
			initMenu();
			
			
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void afficheVue(String uneVue) throws IOException {
		Parent root = FXMLLoader.load(CFunApp.class.getResource(uneVue));
		menu.setCenter(root);
		
	}
	
	public void initMenu() throws Exception {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(CFunApp.class.getResource("view/View_Menu.fxml"));
		try {
			menu = (BorderPane) loader.load();
			Parent root = FXMLLoader.load(CFunApp.class.getResource("View/View_Accueil.fxml"));
			menu.setCenter(root);
			
			MenuController controller = loader.getController();
			controller.setCFunApp(this);
			
			scene = new Scene(menu);

		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}